from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200

def test_match_requires_human_review():
    r = client.post("/match", json={"text": "Python, SQL, FastAPI"})
    assert r.status_code == 200
    assert r.json()["requires_human_review"] is True
    assert "employment decisions" in r.json()["note"].lower()

def test_match_does_not_claim_automated_hiring_decision():
    r = client.post("/match", json={"text": "candidate"})
    assert r.status_code == 200
    assert r.json()["requires_human_review"] is True
