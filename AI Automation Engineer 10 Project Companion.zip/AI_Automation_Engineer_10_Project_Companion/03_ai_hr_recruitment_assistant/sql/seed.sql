INSERT INTO records VALUES ('C001','Ada Okafor','Python;SQL;Pandas',4);
INSERT INTO records VALUES ('C002','Daniel Mensah','Python;FastAPI;SQL',3);
INSERT INTO records VALUES ('C003','Maya Bello','Excel;SQL;Power BI',5);
