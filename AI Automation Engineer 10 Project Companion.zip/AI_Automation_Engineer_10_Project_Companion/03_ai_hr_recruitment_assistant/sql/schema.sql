CREATE TABLE IF NOT EXISTS records (
    "candidate_id" TEXT,
    "candidate" TEXT,
    "skills" TEXT,
    "years_experience" INTEGER
);
