from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").status_code == 200

def test_query_accepts_read_only_select():
    r = client.post("/query", json={"sql": "SELECT * FROM sales"})
    assert r.status_code == 200
    assert r.json()["accepted"] is True

def test_query_rejects_mutating_sql():
    r = client.post("/query", json={"sql": "DROP TABLE sales"})
    assert r.status_code == 400
