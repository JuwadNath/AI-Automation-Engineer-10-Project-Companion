INSERT INTO records VALUES (1,'Sales','Revenue',42000,'2026-01');
INSERT INTO records VALUES (2,'Sales','Revenue',51000,'2026-02');
INSERT INTO records VALUES (3,'Operations','Orders',840,'2026-02');
INSERT INTO records VALUES (4,'Support','Tickets',126,'2026-02');
