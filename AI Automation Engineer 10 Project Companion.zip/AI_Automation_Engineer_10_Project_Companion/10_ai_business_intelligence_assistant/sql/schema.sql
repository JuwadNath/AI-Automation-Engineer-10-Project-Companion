CREATE TABLE IF NOT EXISTS records (
    "id" TEXT,
    "department" TEXT,
    "metric" TEXT,
    "value" REAL,
    "period" TEXT
);
