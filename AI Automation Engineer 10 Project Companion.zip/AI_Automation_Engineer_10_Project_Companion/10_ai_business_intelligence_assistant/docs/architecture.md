# Architecture — AI Business Intelligence Assistant

```text
User / System Event
        |
        v
      n8n  ---> external services / notifications
        |
        v
 FastAPI application
        |
        +--> validation / business rules
        +--> optional LLM/OCR provider
        |
        v
 SQLite/PostgreSQL
```

Human review remains a control point for high-impact or uncertain outcomes. Secrets stay outside source code.
