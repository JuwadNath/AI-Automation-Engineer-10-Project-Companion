CREATE TABLE IF NOT EXISTS records (
    "id" TEXT,
    "question" TEXT,
    "category" TEXT,
    "answer" TEXT,
    "escalate" TEXT
);
