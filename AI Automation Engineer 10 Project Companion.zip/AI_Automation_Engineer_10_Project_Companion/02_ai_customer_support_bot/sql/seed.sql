INSERT INTO records VALUES (1,'How do I reset my password?','account','Use the password reset link on the sign-in page.','false');
INSERT INTO records VALUES (2,'Can I cancel my order?','orders','Cancellation is available before fulfillment.','false');
INSERT INTO records VALUES (3,'I was charged twice.','billing','Billing disputes require human review.','true');
