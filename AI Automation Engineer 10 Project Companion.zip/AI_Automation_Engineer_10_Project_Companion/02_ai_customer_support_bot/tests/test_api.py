from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_known_support_question_uses_verified_answer():
    r = client.post("/ask", json={"text": "I forgot my password"})
    assert r.status_code == 200
    assert "password reset" in r.json()["answer"].lower()
    assert r.json()["escalate"] is False

def test_unknown_support_question_escalates():
    r = client.post("/ask", json={"text": "What is my custom exception?"})
    assert r.status_code == 200
    assert r.json()["escalate"] is True
