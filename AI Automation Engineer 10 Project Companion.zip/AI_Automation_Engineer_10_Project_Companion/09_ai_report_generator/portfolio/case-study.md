# Portfolio Case Study — AI Report Generator

## Business problem
Describe the manual or inefficient process, users, frequency, pain points and business impact.

## Solution
Turn structured data into polished business reports with charts, tables, executive narrative, and PDF/DOCX export.

## Architecture
Document the trigger, n8n orchestration, FastAPI service, model/provider layer, database, integrations and human review points.

## Evidence
Add screenshots, API examples, test output, n8n execution evidence and deployment screenshots.

## Testing
Record happy paths, invalid inputs, empty data, provider failures, timeouts, retries and duplicate events.

## Security
Document least privilege, secret management, authentication/authorization, input validation and safe logging.

## Measurable outcome
Use real measured results where available. Do not invent business outcomes. Suggested metrics: processing time, automation rate, error rate, escalation rate, latency, cost per case, data-quality rate.

## Limitations and next steps
List known limitations and the next production-hardening steps.
