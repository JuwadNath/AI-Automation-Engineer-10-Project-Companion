from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").status_code == 200

def test_report_calculates_profit_and_periods():
    r = client.post("/report", json={"data": [{"revenue": 100, "expenses": 30}, {"revenue": 50, "expenses": 20}]})
    assert r.status_code == 200
    assert r.json() == {"revenue": 150.0, "expenses": 50.0, "profit": 100.0, "periods": 2}

def test_report_empty_data_is_safe():
    assert client.post("/report", json={"data": []}).json()["profit"] == 0
