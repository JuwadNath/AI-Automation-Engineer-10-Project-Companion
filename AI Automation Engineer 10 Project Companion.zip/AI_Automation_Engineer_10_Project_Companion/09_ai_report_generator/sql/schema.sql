CREATE TABLE IF NOT EXISTS records (
    "month" TEXT,
    "revenue" REAL,
    "expenses" REAL,
    "customers" REAL
);
