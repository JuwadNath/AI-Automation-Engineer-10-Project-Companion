import streamlit as st
import pandas as pd
import plotly.express as px
st.set_page_config(page_title="AI Sales Dashboard Generator", layout="wide")
st.title("AI Sales Dashboard Generator")
file = st.file_uploader("Upload sales CSV", type=["csv"])
if file:
    df = pd.read_csv(file)
    revenue = df["sales"].sum() if "sales" in df else 0
    cost = df["cost"].sum() if "cost" in df else 0
    orders = df["orders"].sum() if "orders" in df else 0
    profit = revenue-cost
    c1,c2,c3,c4=st.columns(4)
    c1.metric("Revenue", f"{revenue:,.2f}")
    c2.metric("Cost", f"{cost:,.2f}")
    c3.metric("Profit", f"{profit:,.2f}")
    c4.metric("Orders", f"{orders:,.0f}")
    if {"date","sales"}.issubset(df.columns):
        fig=px.line(df,x="date",y="sales",title="Sales over time")
        st.plotly_chart(fig,use_container_width=True)
    st.dataframe(df, use_container_width=True)
