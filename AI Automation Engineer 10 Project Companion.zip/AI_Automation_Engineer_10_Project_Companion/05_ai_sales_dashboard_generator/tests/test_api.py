from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").status_code == 200

def test_kpis_calculate_revenue_cost_profit_and_margin():
    r = client.post("/kpis", json={"data": [{"sales": 100, "cost": 40, "orders": 2}, {"sales": 50, "cost": 20, "orders": 1}]})
    assert r.status_code == 200
    body = r.json()
    assert body["revenue"] == 150.0
    assert body["cost"] == 60.0
    assert body["profit"] == 90.0
    assert body["orders"] == 3.0
    assert body["margin"] == 0.6

def test_kpis_zero_revenue_has_zero_margin():
    assert client.post("/kpis", json={"data": [{"sales": 0, "cost": 0, "orders": 0}]}).json()["margin"] == 0
