CREATE TABLE IF NOT EXISTS records (
    "date" TEXT,
    "region" TEXT,
    "sales" REAL,
    "cost" REAL,
    "orders" INTEGER
);
