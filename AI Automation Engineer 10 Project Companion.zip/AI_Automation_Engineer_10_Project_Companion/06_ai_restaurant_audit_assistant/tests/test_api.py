from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").status_code == 200

def test_audit_calculates_high_risk_failures():
    r = client.post("/audit", json={"data": [{"status": "fail", "severity": "high"}, {"status": "pass", "severity": "low"}]})
    assert r.status_code == 200
    assert r.json() == {"failed_items": 1, "high_risk": 1, "risk": "high"}

def test_audit_no_failures_is_low_risk():
    assert client.post("/audit", json={"data": [{"status": "pass"}]}).json()["risk"] == "low"
