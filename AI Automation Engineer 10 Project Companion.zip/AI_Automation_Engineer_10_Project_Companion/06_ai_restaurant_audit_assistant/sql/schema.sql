CREATE TABLE IF NOT EXISTS records (
    "inspection_id" TEXT,
    "area" TEXT,
    "item" TEXT,
    "status" TEXT,
    "severity" TEXT
);
