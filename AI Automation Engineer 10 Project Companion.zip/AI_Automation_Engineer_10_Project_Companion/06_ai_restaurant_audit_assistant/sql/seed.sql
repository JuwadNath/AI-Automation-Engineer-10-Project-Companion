INSERT INTO records VALUES ('A001','Kitchen','Handwashing station stocked','pass','low');
INSERT INTO records VALUES ('A001','Kitchen','Cold storage temperature logged','fail','high');
INSERT INTO records VALUES ('A001','Dining','Allergen information visible','pass','medium');
