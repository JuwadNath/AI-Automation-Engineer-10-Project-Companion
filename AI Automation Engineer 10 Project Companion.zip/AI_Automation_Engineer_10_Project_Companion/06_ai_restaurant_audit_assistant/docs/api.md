# API Contract

Base URL: `http://localhost:8000`

## Health
`GET /health`

## Primary operation
`POST /audit`

Example:
```bash
curl -X POST http://localhost:8000/audit \
  -H "Content-Type: application/json" \
  -d '{"text":"demo request","data":[]}'
```

Responses use JSON. Validate schema and business rules before connecting production systems.
