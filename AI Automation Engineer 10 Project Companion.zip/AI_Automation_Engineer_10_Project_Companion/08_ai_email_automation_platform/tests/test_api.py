from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").status_code == 200

def test_classify_marks_security_incident_high_priority():
    r = client.post("/classify", json={"text": "URGENT security fraud issue"})
    assert r.status_code == 200
    assert r.json()["priority"] == "high"
    assert r.json()["escalate"] is True

def test_classify_billing_message():
    r = client.post("/classify", json={"text": "Invoice payment question"})
    assert r.status_code == 200
    assert r.json()["category"] == "billing"
