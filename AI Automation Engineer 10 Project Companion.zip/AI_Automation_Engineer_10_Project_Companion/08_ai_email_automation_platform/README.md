# AI Email Automation Platform

## Objective
Classify inbound messages, draft responses, create tasks, and escalate high-priority mail.

## Stack
Python, IMAP/SMTP, FastAPI, SQL, n8n, LLM API

## Structure
```text
08_ai_email_automation_platform/
├── README.md
├── data/sample.csv
├── app/main.py
├── sql/schema.sql
├── sql/seed.sql
├── n8n/workflow.json
├── docs/architecture.md
├── docs/api.md
├── docs/deployment.md
├── docs/troubleshooting.md
├── tests/test_api.py
├── portfolio/case-study.md
├── requirements.txt
└── .env.example
```

## Run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env  # Windows
uvicorn app.main:app --reload
pytest -q
```

## Production note
This package is a professional demonstration baseline. Add authentication, authorization, managed secrets, HTTPS, observability, persistent database controls, rate limiting, idempotency, evaluation/guardrails, and human approval appropriate to the use case before production.
