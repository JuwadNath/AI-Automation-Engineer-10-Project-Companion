INSERT INTO records VALUES ('E001','Invoice question','billing@example.com','billing','normal');
INSERT INTO records VALUES ('E002','Service outage','ops@example.com','incident','high');
INSERT INTO records VALUES ('E003','Meeting request','sales@example.com','sales','normal');
