CREATE TABLE IF NOT EXISTS records (
    "email_id" TEXT,
    "subject" TEXT,
    "sender" TEXT,
    "category" TEXT,
    "priority" TEXT
);
