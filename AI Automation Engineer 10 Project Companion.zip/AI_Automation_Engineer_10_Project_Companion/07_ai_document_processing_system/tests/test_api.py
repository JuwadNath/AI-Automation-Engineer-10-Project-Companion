from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").status_code == 200

def test_extract_routes_high_value_document_to_approval():
    r = client.post("/extract", json={"data": [{"amount": 1500}]})
    assert r.status_code == 200
    assert r.json() == {"validated": True, "route": "approval"}

def test_extract_requires_data():
    r = client.post("/extract", json={})
    assert r.status_code == 400
