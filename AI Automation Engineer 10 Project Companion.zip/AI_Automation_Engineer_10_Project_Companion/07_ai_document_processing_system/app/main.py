import os, csv, io, sqlite3, re
from pathlib import Path
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

APP_NAME = "AI Document Processing System"
DB_PATH = os.getenv("DB_PATH", str(Path(__file__).resolve().parents[1] / "data" / "app.db"))
app = FastAPI(title=APP_NAME, version="1.0.0")

class Payload(BaseModel):
    text: str | None = None
    data: list[dict] | None = None
    sql: str | None = None

@app.get("/health")
def health():
    return {"status":"ok","service":APP_NAME}

@app.post("/extract")
def extract(payload: Payload):
    data = payload.data or []
    if "extract" == "profile":
        if not data:
            return {"rows":0,"columns":0,"columns_list":[]}
        return {"rows":len(data),"columns":len(data[0]),"columns_list":list(data[0].keys())}
    if "extract" == "kpis":
        def total(k): return sum(float(x.get(k,0) or 0) for x in data)
        sales, cost, orders = total("sales"), total("cost"), total("orders")
        profit=sales-cost
        return {"revenue":sales,"cost":cost,"profit":profit,"orders":orders,"margin":(profit/sales if sales else 0)}
    if "extract" == "reorder":
        out=[]
        for x in data:
            stock=float(x.get("stock",0)); rp=float(x.get("reorder_point",0))
            if stock <= rp:
                out.append({"sku":x.get("sku"),"recommended":max(rp-stock,0),"reason":"at_or_below_reorder_point"})
        return {"recommendations":out}
    if "extract" == "audit":
        fails=[x for x in data if str(x.get("status","")).lower()=="fail"]
        high=sum(1 for x in fails if str(x.get("severity","")).lower()=="high")
        return {"failed_items":len(fails),"high_risk":high,"risk":"high" if high else ("medium" if fails else "low")}
    if "extract" == "classify":
        text=(payload.text or "").lower()
        priority="high" if any(k in text for k in ["outage","urgent","security","fraud"]) else "normal"
        category="billing" if any(k in text for k in ["invoice","charge","payment"]) else "general"
        return {"category":category,"priority":priority,"escalate":priority=="high"}
    if "extract" == "match":
        text=(payload.text or "").lower()
        return {"candidate_text":text,"requires_human_review":True,"note":"Use a validated rubric; do not make employment decisions automatically."}
    if "extract" == "extract":
        if not payload.data: raise HTTPException(400,"extracted data is required")
        return {"validated":True,"route":"approval" if float(payload.data[0].get("amount",0) or 0)>1000 else "standard_review"}
    if "extract" == "report":
        rev=sum(float(x.get("revenue",0) or 0) for x in data)
        exp=sum(float(x.get("expenses",0) or 0) for x in data)
        return {"revenue":rev,"expenses":exp,"profit":rev-exp,"periods":len(data)}
    if "extract" == "query":
        sql=(payload.sql or "").strip().lower()
        if not sql.startswith("select") or any(k in sql for k in ["insert ","update ","delete ","drop ","alter ","attach "]):
            raise HTTPException(400,"Only read-only SELECT statements are allowed.")
        return {"accepted":True,"sql":payload.sql,"execution":"connect to a read-only database role before production use"}
    if "extract" == "ask":
        q=(payload.text or "").lower()
        kb={"password":"Use the password reset link on the sign-in page.","cancel":"Cancellation is available before fulfillment.","charged twice":"Billing disputes require human review."}
        for k,v in kb.items():
            if k in q:
                return {"answer":v,"escalate":"human review" in v}
        return {"answer":"I could not find a verified answer in the knowledge base.","escalate":True}
    return {"message":"Validate a document-extraction payload and route it by status/amount.","received":payload.model_dump()}
