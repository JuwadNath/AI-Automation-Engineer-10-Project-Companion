INSERT INTO records VALUES ('D001','invoice_1001.pdf','invoice','Acme Foods',1250.5,'USD','pending');
INSERT INTO records VALUES ('D002','invoice_1002.pdf','invoice','North Supply',840.0,'USD','approved');
INSERT INTO records VALUES ('D003','receipt_2001.pdf','receipt','Retail Vendor',74.2,'USD','pending');
