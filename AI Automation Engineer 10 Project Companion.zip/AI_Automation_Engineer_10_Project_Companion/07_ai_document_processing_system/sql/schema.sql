CREATE TABLE IF NOT EXISTS records (
    "document_id" TEXT,
    "filename" TEXT,
    "document_type" TEXT,
    "supplier" TEXT,
    "amount" REAL,
    "currency" TEXT,
    "status" TEXT
);
