CREATE TABLE IF NOT EXISTS records (
    "sku" TEXT,
    "product" TEXT,
    "stock" INTEGER,
    "reorder_point" INTEGER,
    "unit_cost" REAL,
    "supplier" TEXT
);
