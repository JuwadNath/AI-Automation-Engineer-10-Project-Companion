INSERT INTO records VALUES ('SKU-001','Wireless Keyboard',24,30,18.5,'North Supply');
INSERT INTO records VALUES ('SKU-002','USB-C Hub',68,40,22.0,'TechSource');
INSERT INTO records VALUES ('SKU-003','Laptop Stand',12,20,31.5,'North Supply');
