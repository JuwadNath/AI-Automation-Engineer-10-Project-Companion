from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    assert client.get("/health").status_code == 200

def test_reorder_flags_only_at_or_below_reorder_point():
    r = client.post("/reorder", json={"data": [{"sku": "A1", "stock": 2, "reorder_point": 5}, {"sku": "B2", "stock": 10, "reorder_point": 5}]})
    assert r.status_code == 200
    assert r.json()["recommendations"] == [{"sku": "A1", "recommended": 3.0, "reason": "at_or_below_reorder_point"}]

def test_reorder_empty_data_is_safe():
    assert client.post("/reorder", json={"data": []}).json()["recommendations"] == []
