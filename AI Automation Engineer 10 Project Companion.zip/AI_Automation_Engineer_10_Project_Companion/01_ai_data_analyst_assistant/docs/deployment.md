# Deployment

1. Python 3.11+ recommended.
2. Create a virtual environment.
3. Install `requirements.txt`.
4. Copy `.env.example` to `.env` and add secrets.
5. Start: `uvicorn app.main:app --reload`.
6. Test: `pytest -q`.
7. Import `n8n/workflow.json` into n8n and change the API URL for your environment.
8. For production, place the API behind HTTPS, use managed secrets, a persistent database, authentication, logging, monitoring, backups, and rollback procedures.
