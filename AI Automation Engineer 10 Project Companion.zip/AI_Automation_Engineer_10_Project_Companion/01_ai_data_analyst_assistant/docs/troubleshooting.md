# Troubleshooting

- **Trigger failure:** verify activation, credentials, webhook URL and payload.
- **HTTP failure:** inspect status code, response body, authentication and rate limits.
- **AI failure:** validate inputs, constrain output, ground responses, and validate structured results.
- **Database failure:** inspect schema, connection string, permissions, indexes and parameterization.
- **Duplicate workflow runs:** add idempotency keys and unique constraints.
- **Timeouts:** set explicit timeouts, batch large requests, and use async processing where appropriate.
- **Data quality:** validate required fields, types, ranges and referential integrity before AI calls.
- **Production incident:** preserve logs, identify the failed component, roll back safely, and document root cause.
