from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_profile_returns_schema_metrics():
    r = client.post("/profile", json={"data": [{"sales": 100, "cost": 60, "orders": 4}, {"sales": 50, "cost": 20, "orders": 2}]})
    assert r.status_code == 200
    assert r.json() == {"rows": 2, "columns": 3, "columns_list": ["sales", "cost", "orders"]}

def test_profile_empty_data_is_safe():
    r = client.post("/profile", json={"data": []})
    assert r.status_code == 200
    assert r.json()["rows"] == 0
