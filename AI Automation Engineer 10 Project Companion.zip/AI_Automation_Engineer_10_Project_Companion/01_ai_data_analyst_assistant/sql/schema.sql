CREATE TABLE IF NOT EXISTS records (
    "date" TEXT,
    "region" TEXT,
    "product" TEXT,
    "revenue" REAL,
    "orders" INTEGER
);
