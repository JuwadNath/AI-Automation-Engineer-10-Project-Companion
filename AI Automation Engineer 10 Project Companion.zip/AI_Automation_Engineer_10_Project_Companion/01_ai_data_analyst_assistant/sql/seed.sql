INSERT INTO records VALUES ('2026-01-05','West','Analytics Suite',4200,12);
INSERT INTO records VALUES ('2026-01-12','East','Automation Hub',6100,18);
INSERT INTO records VALUES ('2026-02-03','West','Automation Hub',7200,21);
INSERT INTO records VALUES ('2026-02-17','South','Analytics Suite',3900,11);
