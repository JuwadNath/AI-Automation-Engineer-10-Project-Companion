import streamlit as st
import pandas as pd
st.set_page_config(page_title="AI Data Analyst Assistant", layout="wide")
st.title("AI Data Analyst Assistant")
file = st.file_uploader("Upload CSV", type=["csv"])
if file:
    df = pd.read_csv(file)
    st.metric("Rows", len(df))
    st.metric("Columns", len(df.columns))
    st.dataframe(df.head(25), use_container_width=True)
    numeric = df.select_dtypes(include="number")
    if not numeric.empty:
        st.subheader("Numeric summary")
        st.dataframe(numeric.describe().T, use_container_width=True)
