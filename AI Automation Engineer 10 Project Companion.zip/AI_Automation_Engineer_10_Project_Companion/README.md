# AI Automation Engineer — 10 Project Companion Package

This package is the implementation companion for the **Commercial AI Automation Engineer — Learn + Build + Portfolio Edition**.

## Purpose
Each project is self-contained and follows the manuscript's Learn → Build → Test → Deploy → Document → Present loop.

## Portfolio standard
Every project includes:
- working local application/API starter
- sample data
- SQL schema and seed data
- exported n8n workflow JSON
- API contract/examples
- architecture and deployment documentation
- troubleshooting notes
- automated API tests
- `.env.example`
- portfolio case-study template

## Important
These are reproducible demonstration implementations, not production-certified systems. Replace demo credentials, secrets, model providers, and business rules before production use. High-impact decisions should retain human review.

## Quick start
Choose a project folder, read its README, create a virtual environment, install `requirements.txt`, copy `.env.example` to `.env`, initialize SQL, run the API, and execute `pytest -q` from the selected project folder. Each project includes `pytest.ini` so the documented command works without setting `PYTHONPATH` manually.

See `PROJECT_MANIFEST.json` for the complete asset map.
